package com.vegan.event.dto;

public class EventDTO {

}
