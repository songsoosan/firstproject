package com.vegan.event.dao;

public interface EventDAO {

}
