package com.vegan.event.service;

public class EventService {

}
