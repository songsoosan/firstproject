package com.vegan.checkList.dao;

public interface CheckListDAO {

}
