package com.vegan.checkList.dto;

public class CheckListDTO {

}
