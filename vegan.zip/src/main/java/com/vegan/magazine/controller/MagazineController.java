package com.vegan.magazine.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MagazineController {

}
