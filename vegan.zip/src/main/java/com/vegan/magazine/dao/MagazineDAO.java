package com.vegan.magazine.dao;

public interface MagazineDAO {

}
