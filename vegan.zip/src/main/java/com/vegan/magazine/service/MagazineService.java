package com.vegan.magazine.service;

public class MagazineService {

}
