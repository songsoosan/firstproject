package com.vegan.magazine.dto;

public class MagazineDTO {

}
