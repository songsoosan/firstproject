package com.vegan.ranking.service;

public class RankingService {

}
