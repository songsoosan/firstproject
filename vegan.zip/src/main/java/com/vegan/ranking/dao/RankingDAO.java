package com.vegan.ranking.dao;

public interface RankingDAO {

}
