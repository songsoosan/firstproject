package com.vegan.ranking.controller;

import org.springframework.stereotype.Controller;

@Controller
public class RankingController {

}
