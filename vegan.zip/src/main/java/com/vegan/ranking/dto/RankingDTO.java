package com.vegan.ranking.dto;

public interface RankingDTO {

}
