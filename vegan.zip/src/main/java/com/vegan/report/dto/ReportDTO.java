package com.vegan.report.dto;

public class ReportDTO {

}
