package com.vegan.report.service;

public class ReportService {

}
