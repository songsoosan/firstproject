package com.vegan.report.dao;

public interface ReportDAO {

}
