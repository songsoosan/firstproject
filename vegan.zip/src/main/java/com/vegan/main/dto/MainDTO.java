package com.vegan.main.dto;

public class MainDTO {
		
}
