package com.vegan.main.dao;

public interface MainDAO {

}
