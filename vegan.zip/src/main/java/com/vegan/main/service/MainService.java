package com.vegan.main.service;

public class MainService {

}
