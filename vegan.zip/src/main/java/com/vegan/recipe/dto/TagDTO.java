package com.vegan.recipe.dto;

public class TagDTO {

	private int tag_id;
	private String tag;
}
