package com.vegan.recipe.dto;

public class foodDTO {

	private String food_name;
	private String food_quantity;
}
