package com.vegan.recipe.dto;

public class RecipeContentDTO {

	private String rec_content;
}
