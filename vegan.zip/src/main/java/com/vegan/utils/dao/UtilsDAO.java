package com.vegan.utils.dao;

public interface UtilsDAO {

}
