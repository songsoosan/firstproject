package com.vegan.utils.dto;

public class UtilsDTO {

}
