package com.vegan.utils.service;

public class UtilsService {

}
