package com.vegan.utils.controller;

import org.springframework.stereotype.Controller;

@Controller
public class UtilsController {

}
